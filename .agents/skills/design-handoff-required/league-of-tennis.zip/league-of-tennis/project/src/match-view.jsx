// Match View — live game in progress.
// Has referee/admin control panel (+1 A, +1 B, Cancel, etc).

const MatchViewScreen = ({ t, asReferee = true }) => {
  const A = { name: 'a.morozov', mmr: 1247, mmrAfter: { win: 1274, loss: 1226 }, init: 'AM', col: t.accent };
  const B = { name: 'k.volkov', mmr: 1289, mmrAfter: { win: 1310, loss: 1268 }, init: 'KV', col: '#3b82f6' };

  const setsA = 1, setsB = 1;       // best of 3 = first to 2
  const curSet = { a: 9, b: 7 };
  const history = [
    { n: 1, a: 11, b: 8, winner: 'A', dur: '6:32' },
    { n: 2, a: 9, b: 11, winner: 'B', dur: '7:14' },
    { n: 3, a: 9, b: 7, winner: null, live: true },
  ];

  const isMatchPoint = false;
  const setPointFor = curSet.a >= 10 ? 'A' : curSet.b >= 10 ? 'B' : null;

  return (
    <div style={{
      width: '100%', minHeight: '100%',
      background: t.bg,
      color: t.text,
      fontFamily: t.fontBody,
      display: 'flex',
      position: 'relative',
      overflow: 'hidden',
    }}>
      <ThemeBg t={t} />
      <DashSidebar t={t} active="matches" />

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <DashTopbar t={t} />

        <div style={{ padding: '24px 32px 32px', display: 'flex', flexDirection: 'column', gap: 20 }}>
          {/* Match meta header */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 16 }}>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                <Pill t={t} color={t.win} filled>
                  <span style={{
                    width: 6, height: 6, borderRadius: '50%', background: t.bg,
                    animation: 'lt-pulse 1.4s infinite',
                  }} />
                  В ПРОЦЕССЕ
                </Pill>
                <Pill t={t} color={t.textMuted}>match #00451</Pill>
                <Pill t={t} color={t.accent2}>BO3</Pill>
                {asReferee && <Pill t={t} color={t.accent} filled>РЕЖИМ РЕФЕРИ</Pill>}
              </div>
              <div style={{
                fontFamily: t.fontDisplay,
                fontWeight: t.displayWeight,
                fontSize: 30,
                lineHeight: 1,
                color: t.text,
                letterSpacing: t.key === 'arena' ? '0.005em' : '-0.02em',
                textTransform: t.key === 'arena' || t.key === 'volt' ? 'uppercase' : 'none',
              }}>{A.name} <span style={{ color: t.textFaint, padding: '0 10px' }}>vs</span> {B.name}</div>
            </div>
            <div style={{ display: 'flex', gap: 22, alignItems: 'flex-start' }}>
              <ChronoBlock t={t} label="время матча" value="14:18" mono />
              <ChronoBlock t={t} label="текущий сет" value="03:22" mono accent />
              <ChronoBlock t={t} label="зрителей" value="24" />
            </div>
          </div>

          {/* SCOREBOARD */}
          <Card t={t} style={{ padding: 0, overflow: 'visible' }}>
            <div style={{
              display: 'grid',
              gridTemplateColumns: asReferee ? '220px 1fr 220px' : '1fr',
              gap: 0,
            }}>
              {/* LEFT — referee controls (Player A side) */}
              {asReferee && (
                <RefereePanel t={t} side="A" color={t.accent} player={A} />
              )}

              {/* CENTER — score */}
              <div style={{
                padding: '36px 24px 28px',
                background: t.key === 'baseline'
                  ? `radial-gradient(ellipse at 50% 0%, rgba(77,212,255,.10), transparent 60%), ${t.surface}`
                  : t.key === 'arena'
                    ? `linear-gradient(180deg, ${t.surface}, ${t.bgAlt})`
                    : t.surface,
                borderLeft: asReferee ? `1px solid ${t.line}` : 'none',
                borderRight: asReferee ? `1px solid ${t.line}` : 'none',
                position: 'relative',
              }}>
                {/* Match-point banner */}
                {setPointFor && (
                  <div style={{
                    position: 'absolute', top: 14, left: '50%', transform: 'translateX(-50%)',
                    padding: '4px 14px',
                    background: t.accent,
                    color: t.bg,
                    fontFamily: t.fontDisplay,
                    fontWeight: t.displayWeight,
                    fontSize: 12,
                    letterSpacing: '0.18em',
                    textTransform: 'uppercase',
                    borderRadius: t.radius,
                    boxShadow: t.key === 'baseline' ? `0 0 24px ${t.accent}` : 'none',
                  }}>сетбол · player {setPointFor}</div>
                )}

                <div style={{ display: 'grid', gridTemplateColumns: '1fr auto 1fr', alignItems: 'center', gap: 16 }}>
                  {/* Player A */}
                  <PlayerSide t={t} player={A} sets={setsA} side="A" align="right" />

                  {/* Score column */}
                  <div style={{ textAlign: 'center', padding: '0 12px' }}>
                    <Label t={t} style={{ marginBottom: 8 }}>сет {history.length} · текущий счёт</Label>
                    <div style={{
                      display: 'flex', alignItems: 'baseline', gap: 14,
                      fontFamily: t.fontDisplay,
                      fontWeight: t.displayWeight,
                      fontVariantNumeric: 'tabular-nums',
                      lineHeight: 0.9,
                    }}>
                      <span style={{ fontSize: 132, color: curSet.a > curSet.b ? t.accent : t.text, letterSpacing: t.key === 'arena' ? '0.005em' : '-0.04em' }}>{curSet.a}</span>
                      <span style={{ fontSize: 64, color: t.textFaint }}>:</span>
                      <span style={{ fontSize: 132, color: curSet.b > curSet.a ? '#3b82f6' : t.text, letterSpacing: t.key === 'arena' ? '0.005em' : '-0.04em' }}>{curSet.b}</span>
                    </div>
                    <div style={{
                      marginTop: 14, display: 'flex', justifyContent: 'center', gap: 20,
                      fontFamily: t.fontMono,
                      fontSize: 11,
                      color: t.textMuted,
                      letterSpacing: '0.1em',
                      textTransform: 'uppercase',
                    }}>
                      <span>сеты: <span style={{ color: t.text, fontWeight: 700 }}>{setsA} – {setsB}</span></span>
                      <span>·</span>
                      <span>до 2 побед</span>
                    </div>
                  </div>

                  {/* Player B */}
                  <PlayerSide t={t} player={B} sets={setsB} side="B" align="left" altColor="#3b82f6" />
                </div>

                {/* Set strip */}
                <div style={{
                  marginTop: 32,
                  paddingTop: 18,
                  borderTop: `1px solid ${t.line}`,
                  display: 'grid',
                  gridTemplateColumns: 'repeat(3, 1fr)',
                  gap: 10,
                }}>
                  {history.map(s => (
                    <div key={s.n} style={{
                      padding: '12px 14px',
                      background: s.live ? t.accentSoft : t.surface2,
                      border: s.live ? `1px solid ${t.accent}` : `1px solid ${t.line}`,
                      borderRadius: t.radius,
                      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                    }}>
                      <div>
                        <Label t={t} style={{ color: s.live ? t.accent : t.textFaint, marginBottom: 4 }}>
                          СЕТ {s.n}{s.live ? ' · LIVE' : ''}
                        </Label>
                        <div style={{
                          fontFamily: t.fontMono,
                          fontSize: 11, color: t.textFaint,
                          letterSpacing: '0.04em',
                        }}>{s.dur || (s.live ? '03:22' : '—')}</div>
                      </div>
                      <div style={{
                        fontFamily: t.fontDisplay,
                        fontWeight: t.displayWeight,
                        fontSize: 26,
                        color: t.text,
                        fontVariantNumeric: 'tabular-nums',
                        letterSpacing: t.key === 'arena' ? '0.01em' : '-0.02em',
                      }}>
                        <span style={{ color: s.winner === 'A' ? t.accent : t.text, opacity: s.winner === 'B' ? 0.45 : 1 }}>{s.a}</span>
                        <span style={{ color: t.textFaint, padding: '0 4px' }}>–</span>
                        <span style={{ color: s.winner === 'B' ? '#3b82f6' : t.text, opacity: s.winner === 'A' ? 0.45 : 1 }}>{s.b}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* RIGHT — referee controls (Player B side) */}
              {asReferee && (
                <RefereePanel t={t} side="B" color="#3b82f6" player={B} />
              )}
            </div>

            {/* Bottom referee bar */}
            {asReferee && (
              <div style={{
                padding: '14px 22px',
                background: t.bgAlt,
                borderTop: `1px solid ${t.line}`,
                display: 'flex', alignItems: 'center', gap: 12,
              }}>
                <Label t={t}>контроль рефери</Label>
                <Btn t={t} ghost size="sm" icon={<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4"><path d="M3 12a9 9 0 1 0 9-9M3 4v8h8"/></svg>}>Отменить очко</Btn>
                <Btn t={t} ghost size="sm" icon={<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4"><path d="M5 12h14M13 6l6 6-6 6"/></svg>}>Завершить сет вручную</Btn>
                <Btn t={t} ghost size="sm">Поменять подачу</Btn>
                <Btn t={t} ghost size="sm">Тайм-аут</Btn>
                <div style={{ flex: 1 }} />
                <Btn t={t} danger size="sm" icon={<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4"><circle cx="12" cy="12" r="10"/><path d="M5 5l14 14"/></svg>}>
                  Отменить матч
                </Btn>
                <span style={{ fontFamily: t.fontMono, fontSize: 10, color: t.textFaint, letterSpacing: '0.08em', textTransform: 'uppercase' }}>
                  MMR не применится
                </span>
              </div>
            )}
          </Card>

          {/* Bottom row: timeline + MMR forecast */}
          <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr', gap: 20 }}>
            <Card t={t}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
                <div style={{
                  fontFamily: t.fontDisplay,
                  fontWeight: t.displayWeight,
                  fontSize: 16,
                  textTransform: t.labelTransform,
                  letterSpacing: t.labelLetter,
                }}>Хронология очков · сет 3</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 14, fontSize: 11, fontFamily: t.fontMono, color: t.textFaint, letterSpacing: '0.06em' }}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}><span style={{ width: 8, height: 8, borderRadius: '50%', background: t.accent }} />A</span>
                  <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}><span style={{ width: 8, height: 8, borderRadius: '50%', background: '#3b82f6' }} />B</span>
                </div>
              </div>
              <PointTimeline t={t} />
            </Card>

            <Card t={t}>
              <div style={{
                fontFamily: t.fontDisplay,
                fontWeight: t.displayWeight,
                fontSize: 16,
                textTransform: t.labelTransform,
                letterSpacing: t.labelLetter,
                marginBottom: 14,
              }}>Прогноз MMR</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                <ForecastRow t={t} player={A} cur={A.mmr} after={A.mmrAfter} />
                <ForecastRow t={t} player={B} cur={B.mmr} after={B.mmrAfter} altColor="#3b82f6" />
              </div>
              <div style={{
                marginTop: 14, padding: '10px 12px',
                background: t.surface2,
                borderRadius: t.radius,
                fontSize: 11, color: t.textMuted, lineHeight: 1.5,
                fontFamily: t.fontMono,
                letterSpacing: '0.02em',
              }}>
                Изменение MMR симметрично · базовая ставка 25, скорректирована под разницу рейтингов.
              </div>
            </Card>
          </div>
        </div>
      </div>

      <style>{`@keyframes lt-pulse { 0%,100%{opacity:1} 50%{opacity:.3} }`}</style>
    </div>
  );
};

const ChronoBlock = ({ t, label, value, mono, accent }) => (
  <div style={{ textAlign: 'right' }}>
    <Label t={t} style={{ marginBottom: 4 }}>{label}</Label>
    <div style={{
      fontFamily: mono ? t.fontMono : t.fontDisplay,
      fontWeight: 600,
      fontSize: 24,
      color: accent ? t.accent : t.text,
      fontVariantNumeric: 'tabular-nums',
      letterSpacing: '0.02em',
      lineHeight: 1,
    }}>{value}</div>
  </div>
);

const PlayerSide = ({ t, player, sets, side, align, altColor }) => (
  <div style={{ display: 'flex', flexDirection: 'column', alignItems: align === 'right' ? 'flex-end' : 'flex-start', gap: 14 }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 14, flexDirection: align === 'right' ? 'row-reverse' : 'row' }}>
      <Avatar t={t} initials={player.init} color={altColor || t.accent} size={56} />
      <div style={{ textAlign: align }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, justifyContent: align === 'right' ? 'flex-end' : 'flex-start' }}>
          <Label t={t} style={{ color: altColor || t.accent }}>P{side}</Label>
          <span style={{ fontFamily: t.fontMono, fontSize: 10, color: t.textFaint, letterSpacing: '0.08em' }}>·</span>
          <Label t={t}>{side === 'A' ? 'подача' : ''}</Label>
        </div>
        <div style={{
          fontFamily: t.fontDisplay,
          fontWeight: t.displayWeight,
          fontSize: 22,
          marginTop: 4,
          color: t.text,
          letterSpacing: t.key === 'arena' ? '0.01em' : '-0.01em',
        }}>{player.name}</div>
        <div style={{ fontSize: 11, color: t.textFaint, fontFamily: t.fontMono, letterSpacing: '0.04em', marginTop: 2 }}>
          MMR {player.mmr}
        </div>
      </div>
    </div>
    {/* Sets won — diamond pips */}
    <div style={{ display: 'flex', gap: 6 }}>
      {[0, 1].map(i => {
        const won = i < sets;
        return (
          <div key={i} style={{
            width: 30, height: 30,
            borderRadius: t.key === 'baseline' ? 8 : t.radius,
            background: won ? (altColor || t.accent) : 'transparent',
            border: won ? 'none' : `1.5px solid ${t.line}`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: t.fontMono,
            fontSize: 12,
            fontWeight: 700,
            color: won ? t.bg : t.textFaint,
          }}>{won ? '✓' : i + 1}</div>
        );
      })}
    </div>
  </div>
);

const RefereePanel = ({ t, side, color, player }) => (
  <div style={{
    padding: '24px 18px',
    background: t.bgAlt,
    display: 'flex', flexDirection: 'column', gap: 14,
  }}>
    <div>
      <Label t={t} style={{ color, marginBottom: 6 }}>player {side}</Label>
      <div style={{
        fontFamily: t.fontDisplay,
        fontWeight: t.displayWeight,
        fontSize: 16,
        color: t.text,
        textTransform: t.labelTransform,
        letterSpacing: t.labelLetter,
      }}>{player.name}</div>
    </div>

    {/* Big +1 button */}
    <button style={{
      padding: '20px 14px',
      background: color,
      color: t.bg,
      border: 'none',
      borderRadius: t.radiusLg,
      cursor: 'pointer',
      fontFamily: t.fontDisplay,
      fontWeight: t.displayWeight,
      letterSpacing: '0.02em',
      boxShadow: t.key === 'baseline' ? `0 0 32px ${color}55` : `0 4px 0 -2px ${color}55`,
    }}>
      <div style={{ fontSize: 38, lineHeight: 0.9 }}>+1</div>
      <div style={{ fontSize: 11, opacity: 0.7, fontFamily: t.fontMono, letterSpacing: '0.16em', marginTop: 6, textTransform: 'uppercase' }}>
        очко · player {side}
      </div>
    </button>

    {/* Quick keyboard hint */}
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
      fontSize: 10, color: t.textFaint, fontFamily: t.fontMono, letterSpacing: '0.06em',
      textTransform: 'uppercase',
    }}>
      <span>клавиша</span>
      <span style={{
        padding: '2px 6px', background: t.surface2, color: t.text,
        borderRadius: 3, border: `1px solid ${t.line}`,
        fontWeight: 700,
      }}>{side === 'A' ? 'A' : 'L'}</span>
    </div>

    <div style={{ flex: 1 }} />

    {/* Mini undo */}
    <Btn t={t} ghost size="sm" full>
      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6"><path d="M3 12a9 9 0 1 0 9-9M3 4v8h8"/></svg>
      Undo {side}
    </Btn>
  </div>
);

const PointTimeline = ({ t }) => {
  const points = [
    'A','A','B','A','B','B','A','A','A','B','A','B','A','B','A','A',
  ];
  return (
    <div>
      <div style={{ display: 'flex', gap: 4, marginBottom: 14 }}>
        {points.map((p, i) => (
          <div key={i} style={{
            flex: 1,
            height: 36,
            position: 'relative',
            background: t.surface2,
            borderRadius: t.key === 'volt' ? 0 : 3,
          }}>
            <div style={{
              position: 'absolute',
              left: 0, right: 0,
              ...(p === 'A'
                ? { top: 0, bottom: '50%', background: t.accent, borderRadius: t.key === 'volt' ? 0 : '3px 3px 0 0' }
                : { top: '50%', bottom: 0, background: '#3b82f6', borderRadius: t.key === 'volt' ? 0 : '0 0 3px 3px' }),
            }} />
          </div>
        ))}
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: t.fontMono, fontSize: 11, color: t.textFaint, letterSpacing: '0.06em' }}>
        <span>0–0</span>
        <span style={{ color: t.text, fontWeight: 700 }}>9–7</span>
      </div>
      <div style={{ marginTop: 14, paddingTop: 12, borderTop: `1px solid ${t.line}`, display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
        {[
          ['Серия A', '3'],
          ['Серия B', '2'],
          ['Длинн. розыгрыш', '14'],
          ['Эйсы A', '5'],
        ].map(([l, v]) => (
          <div key={l}>
            <Label t={t} style={{ marginBottom: 4 }}>{l}</Label>
            <div style={{
              fontFamily: t.fontMono, fontSize: 16, fontWeight: 700, color: t.text,
              fontVariantNumeric: 'tabular-nums',
            }}>{v}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

const ForecastRow = ({ t, player, cur, after, altColor }) => (
  <div style={{
    padding: '12px 14px',
    background: t.surface2,
    borderRadius: t.radius,
    border: t.key === 'volt' ? `1px solid ${t.line}` : 'none',
  }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
      <Avatar t={t} initials={player.init} color={altColor || t.accent} size={26} />
      <div style={{ fontSize: 13, color: t.text, fontWeight: 500 }}>{player.name}</div>
      <div style={{ marginLeft: 'auto', fontFamily: t.fontMono, fontSize: 12, color: t.textMuted, fontVariantNumeric: 'tabular-nums' }}>
        {cur}
      </div>
    </div>
    <div style={{ display: 'flex', gap: 8 }}>
      <div style={{
        flex: 1, padding: '8px 10px',
        borderRadius: t.radius,
        border: `1px solid ${t.win}55`,
        background: t.key === 'baseline' ? 'rgba(61,214,140,.08)' : 'transparent',
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
          <Label t={t} style={{ color: t.win }}>WIN</Label>
          <div style={{
            fontFamily: t.fontMono, fontSize: 14, fontWeight: 700, color: t.win,
            fontVariantNumeric: 'tabular-nums',
          }}>+{after.win - cur}</div>
        </div>
        <div style={{ fontFamily: t.fontDisplay, fontWeight: t.displayWeight, fontSize: 18, color: t.text, fontVariantNumeric: 'tabular-nums', marginTop: 2, letterSpacing: t.key === 'arena' ? '0.01em' : '-0.02em' }}>
          {after.win}
        </div>
      </div>
      <div style={{
        flex: 1, padding: '8px 10px',
        borderRadius: t.radius,
        border: `1px solid ${t.loss}44`,
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
          <Label t={t} style={{ color: t.loss }}>LOSS</Label>
          <div style={{
            fontFamily: t.fontMono, fontSize: 14, fontWeight: 700, color: t.loss,
            fontVariantNumeric: 'tabular-nums',
          }}>{after.loss - cur}</div>
        </div>
        <div style={{ fontFamily: t.fontDisplay, fontWeight: t.displayWeight, fontSize: 18, color: t.text, fontVariantNumeric: 'tabular-nums', marginTop: 2, letterSpacing: t.key === 'arena' ? '0.01em' : '-0.02em' }}>
          {after.loss}
        </div>
      </div>
    </div>
  </div>
);

window.MatchViewScreen = MatchViewScreen;
