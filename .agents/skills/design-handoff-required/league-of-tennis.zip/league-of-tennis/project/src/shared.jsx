// Shared atoms used across all screens.
// All take a `t` prop = theme object from window.THEMES.

const Avatar = ({ initials, color, size = 36, t }) => (
  <div style={{
    width: size, height: size, borderRadius: t.key === 'baseline' ? '50%' : t.radius,
    background: color || t.surface2,
    color: t.text,
    fontFamily: t.fontDisplay,
    fontWeight: t.displayWeight,
    fontSize: size * 0.42,
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    flex: '0 0 auto',
    border: t.key === 'volt' ? `1px solid ${t.line}` : 'none',
    letterSpacing: t.key === 'arena' ? '0.04em' : '0',
  }}>{initials}</div>
);

const Pill = ({ children, color, t, filled }) => (
  <span style={{
    display: 'inline-flex', alignItems: 'center', gap: 6,
    padding: '4px 10px',
    borderRadius: t.key === 'volt' ? 2 : 999,
    background: filled ? color : 'transparent',
    color: filled ? t.bg : (color || t.textMuted),
    border: filled ? 'none' : `1px solid ${color || t.line}`,
    fontFamily: t.fontMono,
    fontSize: 11,
    fontWeight: 600,
    letterSpacing: '0.06em',
    textTransform: 'uppercase',
    lineHeight: 1,
  }}>{children}</span>
);

const Btn = ({ children, primary, ghost, danger, t, onClick, full, icon, size = 'md', style = {} }) => {
  const heights = { sm: 30, md: 40, lg: 48 };
  const h = heights[size];
  const base = {
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
    height: h, padding: `0 ${size === 'sm' ? 12 : 18}px`,
    borderRadius: t.radius,
    fontFamily: t.fontDisplay,
    fontWeight: t.displayWeight,
    fontSize: size === 'sm' ? 12 : 14,
    letterSpacing: t.labelLetter,
    textTransform: t.labelTransform,
    cursor: 'pointer',
    border: 'none',
    width: full ? '100%' : 'auto',
    transition: 'all .15s',
    ...style,
  };
  let style2;
  if (primary) {
    style2 = { background: t.accent, color: t.bg };
    if (t.key === 'arena') style2.boxShadow = `0 0 0 1px ${t.accent}, 0 4px 0 -2px rgba(255,91,31,.35)`;
    if (t.key === 'volt') style2.color = '#0a0d10';
    if (t.key === 'baseline') style2.boxShadow = `0 0 24px rgba(77,212,255,.35), 0 0 0 1px rgba(77,212,255,.6)`;
  } else if (danger) {
    style2 = { background: 'transparent', color: t.loss, boxShadow: `inset 0 0 0 1px ${t.loss}` };
  } else if (ghost) {
    style2 = { background: 'transparent', color: t.textMuted, boxShadow: `inset 0 0 0 1px ${t.line}` };
  } else {
    style2 = { background: t.surface2, color: t.text, boxShadow: `inset 0 0 0 1px ${t.line}` };
  }
  return (
    <button onClick={onClick} style={{ ...base, ...style2 }}>
      {icon && <span style={{ display: 'flex' }}>{icon}</span>}
      {children}
    </button>
  );
};

const Card = ({ children, t, style = {}, padded = true, accent }) => (
  <div style={{
    background: t.surface,
    borderRadius: t.radiusLg,
    padding: padded ? 20 : 0,
    boxShadow: t.cardShadow,
    border: t.key === 'baseline' ? t.panelBorder : 'none',
    backdropFilter: t.key === 'baseline' ? 'blur(20px)' : 'none',
    position: 'relative',
    ...style,
  }}>
    {accent && <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: t.accent }} />}
    {children}
  </div>
);

const Label = ({ children, t, style = {} }) => (
  <div style={{
    fontFamily: t.fontMono,
    fontSize: 10,
    fontWeight: 600,
    letterSpacing: t.key === 'volt' ? '0.1em' : '0.16em',
    textTransform: 'uppercase',
    color: t.textMuted,
    ...style,
  }}>{children}</div>
);

// Inline mini ELO sparkline. data = numbers
const Spark = ({ data, color, w = 120, h = 32, t }) => {
  const min = Math.min(...data), max = Math.max(...data);
  const range = max - min || 1;
  const pts = data.map((v, i) => [(i / (data.length - 1)) * w, h - ((v - min) / range) * (h - 4) - 2]);
  const d = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ');
  const last = pts[pts.length - 1];
  return (
    <svg width={w} height={h} style={{ display: 'block' }}>
      <path d={d} stroke={color || t.accent} strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx={last[0]} cy={last[1]} r="2.5" fill={color || t.accent} />
    </svg>
  );
};

// Logo glyph — paddle-and-ball mark, themed.
const Logo = ({ t, size = 28 }) => (
  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none">
      <rect x="2" y="2" width="28" height="28" rx={t.key === 'volt' ? 1 : 6} stroke={t.accent} strokeWidth="2" />
      <circle cx="11" cy="11" r="3.5" fill={t.accent} />
      <path d="M14 14 L24 24" stroke={t.accent} strokeWidth="2.4" strokeLinecap="round" />
      <circle cx="24" cy="24" r="2" fill={t.text} />
    </svg>
    <div style={{
      fontFamily: t.fontDisplay,
      fontWeight: t.displayWeight,
      fontSize: size * 0.62,
      letterSpacing: t.key === 'arena' ? '0.04em' : '-0.01em',
      color: t.text,
      textTransform: t.key === 'arena' || t.key === 'volt' ? 'uppercase' : 'none',
      lineHeight: 1,
    }}>
      {t.key === 'volt' ? 'L/T' : 'League of Tennis'}
    </div>
  </div>
);

// Decorative grid bg (for volt) / dot bg / radial glow
const ThemeBg = ({ t }) => {
  if (t.key === 'arena') {
    return (
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none',
        backgroundImage: `radial-gradient(ellipse 80% 50% at 50% 0%, rgba(255,91,31,.08), transparent 60%)`,
      }} />
    );
  }
  if (t.key === 'volt') {
    return (
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', opacity: 0.5,
        backgroundImage: `linear-gradient(rgba(194,255,62,.05) 1px, transparent 1px), linear-gradient(90deg, rgba(194,255,62,.05) 1px, transparent 1px)`,
        backgroundSize: '32px 32px',
      }} />
    );
  }
  if (t.key === 'baseline') {
    return (
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none',
        backgroundImage: `radial-gradient(ellipse 60% 40% at 20% 0%, rgba(77,212,255,.12), transparent 60%), radial-gradient(ellipse 50% 40% at 90% 90%, rgba(167,139,250,.10), transparent 60%)`,
      }} />
    );
  }
  return null;
};

Object.assign(window, { Avatar, Pill, Btn, Card, Label, Spark, Logo, ThemeBg });
