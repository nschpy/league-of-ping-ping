// Create Match — referee creates a game (players + format).

const CreateMatchScreen = ({ t }) => {
  const [playerA, playerB] = [
    { name: 'a.morozov', mmr: 1247, init: 'AM', col: t.accent, country: 'RU', wr: 68, streak: '5W' },
    { name: 'k.volkov', mmr: 1289, init: 'KV', col: '#3b82f6', country: 'RU', wr: 71, streak: '2W' },
  ];

  const FormatCard = ({ k, label, sets, popular }) => {
    const active = k === 'bo3';
    return (
      <div style={{
        flex: 1,
        padding: '20px 18px',
        borderRadius: t.radiusLg,
        background: active ? t.accentSoft : t.surface,
        border: active ? `1.5px solid ${t.accent}` : `1px solid ${t.line}`,
        position: 'relative',
        cursor: 'pointer',
      }}>
        {popular && (
          <div style={{
            position: 'absolute', top: -10, right: 14,
            background: t.accent2,
            color: t.bg,
            padding: '3px 8px',
            borderRadius: t.radius,
            fontFamily: t.fontMono,
            fontSize: 9,
            fontWeight: 700,
            letterSpacing: '0.1em',
            textTransform: 'uppercase',
          }}>POPULAR</div>
        )}
        <div style={{
          fontFamily: t.fontDisplay,
          fontWeight: t.displayWeight,
          fontSize: 36,
          lineHeight: 1,
          color: active ? t.accent : t.text,
          letterSpacing: t.key === 'arena' ? '0.01em' : '-0.02em',
        }}>{label}</div>
        <div style={{ fontSize: 12, color: t.textMuted, marginTop: 6 }}>{sets}</div>
        <div style={{ marginTop: 14, display: 'flex', gap: 4 }}>
          {Array.from({ length: k === 'bo1' ? 1 : k === 'bo3' ? 3 : 5 }).map((_, i) => (
            <div key={i} style={{
              flex: 1, height: 5,
              background: active ? t.accent : t.line,
              borderRadius: t.key === 'volt' ? 0 : 3,
              opacity: active ? (i === 0 ? 1 : 0.45) : 1,
            }} />
          ))}
        </div>
      </div>
    );
  };

  const PlayerSlot = ({ p, side, color }) => (
    <div style={{
      flex: 1,
      padding: 22,
      borderRadius: t.radiusLg,
      background: t.surface,
      border: `1px solid ${t.line}`,
      borderTop: `3px solid ${color}`,
      position: 'relative',
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
        <Label t={t} style={{ color }}>{side}</Label>
        <span style={{ fontFamily: t.fontMono, fontSize: 11, color: t.textFaint, letterSpacing: '0.08em' }}>
          {side === 'PLAYER A' ? 'подача' : 'приём'}
        </span>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 18 }}>
        <Avatar t={t} initials={p.init} color={p.col} size={56} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{
            fontFamily: t.fontDisplay,
            fontWeight: t.displayWeight,
            fontSize: 22,
            color: t.text,
            letterSpacing: t.key === 'arena' ? '0.01em' : '-0.01em',
          }}>{p.name}</div>
          <div style={{ fontSize: 12, color: t.textFaint, fontFamily: t.fontMono, letterSpacing: '0.06em', marginTop: 2 }}>
            {p.country} · GOLD · {p.streak}
          </div>
        </div>
        <div style={{
          textAlign: 'right',
        }}>
          <Label t={t}>MMR</Label>
          <div style={{
            fontFamily: t.fontDisplay,
            fontWeight: t.displayWeight,
            fontSize: 30,
            color: t.text,
            fontVariantNumeric: 'tabular-nums',
            lineHeight: 1,
            marginTop: 4,
            letterSpacing: '-0.02em',
          }}>{p.mmr}</div>
        </div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
        {[
          ['Винрейт', `${p.wr}%`],
          ['Матчей', '50'],
          ['Серия', p.streak],
        ].map(([l, v]) => (
          <div key={l} style={{
            padding: '10px 12px',
            background: t.surface2,
            borderRadius: t.radius,
            border: t.key === 'volt' ? `1px solid ${t.line}` : 'none',
          }}>
            <Label t={t}>{l}</Label>
            <div style={{
              fontFamily: t.fontMono,
              fontSize: 14,
              fontWeight: 600,
              color: t.text,
              marginTop: 3,
              fontVariantNumeric: 'tabular-nums',
            }}>{v}</div>
          </div>
        ))}
      </div>
      <div style={{
        marginTop: 14,
        padding: '10px 12px',
        background: 'transparent',
        border: `1px dashed ${t.line}`,
        borderRadius: t.radius,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        fontSize: 12,
      }}>
        <span style={{ color: t.textMuted }}>сменить игрока</span>
        <span style={{ color: t.accent, fontFamily: t.fontMono, letterSpacing: '0.06em' }}>выбрать →</span>
      </div>
    </div>
  );

  return (
    <div style={{
      width: '100%', minHeight: '100%',
      background: t.bg,
      color: t.text,
      fontFamily: t.fontBody,
      display: 'flex',
      position: 'relative',
      overflow: 'hidden',
    }}>
      <ThemeBg t={t} />
      <DashSidebar t={t} active="play" />

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <DashTopbar t={t} />

        <div style={{ padding: '28px 40px 40px', display: 'flex', flexDirection: 'column', gap: 24, maxWidth: 1180 }}>
          {/* Header */}
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 24 }}>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, color: t.textFaint, fontSize: 12, fontFamily: t.fontMono, letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 10 }}>
                <span>Матчи</span>
                <span>/</span>
                <span style={{ color: t.accent }}>Новый матч</span>
              </div>
              <div style={{
                fontFamily: t.fontDisplay,
                fontWeight: t.displayWeight,
                fontSize: 44,
                lineHeight: 1,
                color: t.text,
                letterSpacing: t.key === 'arena' ? '0.005em' : '-0.03em',
                textTransform: t.key === 'arena' || t.key === 'volt' ? 'uppercase' : 'none',
              }}>Создать матч</div>
              <div style={{ color: t.textMuted, fontSize: 14, marginTop: 8, maxWidth: 540 }}>
                Рефери выбирает участников и формат. После старта результаты сетов фиксируются здесь же.
              </div>
            </div>
            <Pill t={t} color={t.accent2}>
              <span style={{ width: 6, height: 6, borderRadius: '50%', background: t.accent2 }} />
              Ты — рефери
            </Pill>
          </div>

          {/* Players */}
          <div>
            <Label t={t} style={{ marginBottom: 12 }}>1. Участники</Label>
            <div style={{ display: 'flex', alignItems: 'stretch', gap: 16, position: 'relative' }}>
              <PlayerSlot p={playerA} side="PLAYER A" color={t.accent} />
              <div style={{
                position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
                width: 52, height: 52,
                borderRadius: t.key === 'baseline' ? '50%' : t.radius,
                background: t.bg,
                border: `1.5px solid ${t.line}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: t.fontDisplay,
                fontWeight: t.displayWeight,
                fontSize: 14,
                color: t.textMuted,
                letterSpacing: '0.04em',
                zIndex: 2,
              }}>VS</div>
              <PlayerSlot p={playerB} side="PLAYER B" color="#3b82f6" />
            </div>
          </div>

          {/* Format */}
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <Label t={t}>2. Формат</Label>
              <span style={{ fontSize: 12, color: t.textFaint, fontFamily: t.fontMono, letterSpacing: '0.06em' }}>
                выбран · BO3 (до 2 побед в сетах)
              </span>
            </div>
            <div style={{ display: 'flex', gap: 12 }}>
              <FormatCard k="bo1" label="BO1" sets="1 сет — быстрая дуэль" />
              <FormatCard k="bo3" label="BO3" sets="до 2 побед в сетах" popular />
              <FormatCard k="bo5" label="BO5" sets="до 3 побед — серьёзная серия" />
            </div>
          </div>

          {/* Match summary */}
          <Card t={t} style={{ padding: 0 }} accent={t.key === 'arena'}>
            <div style={{
              padding: '16px 22px',
              borderBottom: `1px solid ${t.line}`,
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <Label t={t}>сводка матча</Label>
                <Pill t={t} color={t.textMuted}>match #00451</Pill>
              </div>
              <span style={{ fontFamily: t.fontMono, fontSize: 11, color: t.textFaint, letterSpacing: '0.06em' }}>
                будет создана сразу после старта
              </span>
            </div>
            <div style={{ padding: 22, display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: 0 }}>
              {[
                ['Формат', 'BO3', t.text],
                ['Разница MMR', '−42', t.loss],
                ['При победе', '+27', t.win],
                ['При поражении', '−21', t.loss],
              ].map(([l, v, c], i) => (
                <div key={i} style={{
                  padding: '0 18px',
                  borderLeft: i ? `1px solid ${t.line}` : 'none',
                }}>
                  <Label t={t}>{l}</Label>
                  <div style={{
                    fontFamily: t.fontDisplay,
                    fontWeight: t.displayWeight,
                    fontSize: 28,
                    color: c,
                    fontVariantNumeric: 'tabular-nums',
                    marginTop: 8,
                    letterSpacing: t.key === 'arena' ? '0.01em' : '-0.02em',
                  }}>{v}</div>
                </div>
              ))}
            </div>
          </Card>

          {/* Actions */}
          <div style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            paddingTop: 8,
          }}>
            <div style={{ fontSize: 12, color: t.textFaint, display: 'flex', alignItems: 'center', gap: 8 }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><path d="M12 8v4l3 2"/></svg>
              После старта матч получит статус «В процессе»
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <Btn t={t} ghost size="lg">Отмена</Btn>
              <Btn t={t} ghost size="lg">Сохранить как черновик</Btn>
              <Btn t={t} primary size="lg" icon={<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>}>Старт матча</Btn>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

window.CreateMatchScreen = CreateMatchScreen;
