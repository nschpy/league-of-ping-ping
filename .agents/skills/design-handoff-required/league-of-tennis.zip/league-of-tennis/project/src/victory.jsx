// Victory Screen — replaces live score with the winning player's name.
// Final sets, set-by-set breakdown, MMR change, duration. Loser shown dimmed.

const VictoryScreen = ({ t, winner = 'A' }) => {
  const A = { name: 'a.morozov', mmr: 1247, mmrAfter: 1274, init: 'AM', col: t.accent };
  const B = { name: 'k.volkov', mmr: 1289, mmrAfter: 1268, init: 'KV', col: '#3b82f6' };

  const setsA = winner === 'A' ? 2 : 1;
  const setsB = winner === 'A' ? 1 : 2;

  const history = [
    { n: 1, a: 11, b: 8, winner: 'A', dur: '6:32' },
    { n: 2, a: 9, b: 11, winner: 'B', dur: '7:14' },
    { n: 3, a: winner === 'A' ? 11 : 9, b: winner === 'A' ? 9 : 11, winner, dur: '8:04' },
  ];

  const W = winner === 'A' ? A : B;
  const L = winner === 'A' ? B : A;
  const wColor = winner === 'A' ? t.accent : '#3b82f6';
  const lColor = winner === 'A' ? '#3b82f6' : t.accent;

  return (
    <div style={{
      width: '100%', minHeight: '100%',
      background: t.bg,
      color: t.text,
      fontFamily: t.fontBody,
      display: 'flex',
      position: 'relative',
      overflow: 'hidden',
    }}>
      <ThemeBg t={t} />
      {/* Extra theatrical glow behind winner */}
      <div style={{
        position: 'absolute', inset: 0, pointerEvents: 'none',
        backgroundImage: t.key === 'baseline'
          ? `radial-gradient(ellipse 60% 50% at 50% 35%, ${wColor}33, transparent 65%)`
          : t.key === 'arena'
            ? `radial-gradient(ellipse 70% 55% at 50% 30%, ${wColor}22, transparent 65%)`
            : `radial-gradient(ellipse 60% 45% at 50% 30%, ${wColor}18, transparent 65%)`,
      }} />

      <DashSidebar t={t} active="matches" />

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0, position: 'relative' }}>
        <DashTopbar t={t} />

        <div style={{ padding: '24px 32px 32px', display: 'flex', flexDirection: 'column', gap: 20 }}>
          {/* Top meta */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <Pill t={t} color={t.win} filled>
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><path d="M5 12l5 5L20 7"/></svg>
                МАТЧ ЗАВЕРШЁН
              </Pill>
              <Pill t={t} color={t.textMuted}>match #00451</Pill>
              <Pill t={t} color={t.accent2}>BO3</Pill>
              <Pill t={t} color={t.textMuted}>результат подтверждён</Pill>
            </div>
            <div style={{ display: 'flex', gap: 22, alignItems: 'flex-start' }}>
              <ChronoBlock t={t} label="общее время" value="21:50" mono />
              <ChronoBlock t={t} label="очков сыграно" value="48" />
              <ChronoBlock t={t} label="зрителей" value="24" />
            </div>
          </div>

          {/* HERO — WINNER PANEL */}
          <Card t={t} accent={t.key === 'arena'} style={{
            padding: 0, overflow: 'hidden',
            background: t.key === 'baseline'
              ? `linear-gradient(180deg, ${wColor}14, transparent 60%), ${t.surface}`
              : t.key === 'arena'
                ? `linear-gradient(180deg, ${t.surface}, ${t.bgAlt})`
                : t.surface,
            position: 'relative',
          }}>
            {/* Confetti / streak decoration */}
            {t.key === 'volt' && (
              <div style={{
                position: 'absolute', inset: 0, pointerEvents: 'none',
                backgroundImage: `repeating-linear-gradient(45deg, ${wColor}10 0 1px, transparent 1px 14px)`,
              }} />
            )}

            <div style={{ padding: '48px 32px 36px', textAlign: 'center', position: 'relative' }}>
              {/* WINNER label */}
              <div style={{
                display: 'inline-flex', alignItems: 'center', gap: 12,
                padding: '6px 18px',
                background: wColor,
                color: t.bg,
                fontFamily: t.fontDisplay,
                fontWeight: t.displayWeight,
                fontSize: 13,
                letterSpacing: '0.24em',
                textTransform: 'uppercase',
                borderRadius: t.radius,
                marginBottom: 28,
                boxShadow: t.key === 'baseline'
                  ? `0 0 32px ${wColor}88`
                  : t.key === 'arena'
                    ? `0 0 0 1px ${wColor}, 0 0 24px ${wColor}55`
                    : 'none',
              }}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M5 16L3 5l5.5 4L12 4l3.5 5L21 5l-2 11H5zm0 2h14v3H5v-3z"/></svg>
                ПОБЕДИТЕЛЬ
                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M5 16L3 5l5.5 4L12 4l3.5 5L21 5l-2 11H5zm0 2h14v3H5v-3z"/></svg>
              </div>

              {/* Avatar + winner identity */}
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 18 }}>
                <div style={{ position: 'relative' }}>
                  <Avatar t={t} initials={W.init} color={wColor} size={104} />
                  {/* Halo */}
                  <div style={{
                    position: 'absolute', inset: -8,
                    borderRadius: t.key === 'baseline' ? '50%' : t.radiusLg,
                    border: `2px solid ${wColor}`,
                    opacity: 0.35,
                    pointerEvents: 'none',
                  }} />
                </div>

                {/* Side label */}
                <Label t={t} style={{ color: wColor, letterSpacing: '0.24em', fontSize: 11 }}>
                  PLAYER {winner} · WIN
                </Label>

                {/* WINNER NAME — in place of the score */}
                <div style={{
                  fontFamily: t.fontDisplay,
                  fontWeight: t.displayWeight,
                  fontSize: 76,
                  lineHeight: 0.9,
                  color: t.text,
                  letterSpacing: t.key === 'arena' ? '0.01em' : '-0.035em',
                  textTransform: t.key === 'arena' || t.key === 'volt' ? 'uppercase' : 'none',
                  textShadow: t.key === 'baseline' ? `0 0 60px ${wColor}55` : 'none',
                  maxWidth: '100%',
                  wordBreak: 'break-word',
                  minHeight: 116,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>{W.name}</div>

                {/* Final sets — small badge underneath, not the focus */}
                <div style={{
                  display: 'inline-flex', alignItems: 'center', gap: 18,
                  padding: '14px 24px',
                  background: t.surface2,
                  border: `1px solid ${t.line}`,
                  borderRadius: t.radius,
                  marginTop: 8,
                }}>
                  <Label t={t}>финальный счёт</Label>
                  <div style={{
                    display: 'flex', alignItems: 'baseline', gap: 10,
                    fontFamily: t.fontMono,
                    fontWeight: 700,
                    fontVariantNumeric: 'tabular-nums',
                  }}>
                    <span style={{ fontSize: 28, color: winner === 'A' ? t.text : t.textFaint }}>{setsA}</span>
                    <span style={{ fontSize: 18, color: t.textFaint }}>:</span>
                    <span style={{ fontSize: 28, color: winner === 'B' ? t.text : t.textFaint }}>{setsB}</span>
                  </div>
                  <span style={{ width: 1, height: 18, background: t.line }} />
                  <div style={{ fontFamily: t.fontMono, fontSize: 11, color: t.textMuted, letterSpacing: '0.1em', textTransform: 'uppercase' }}>
                    {history.map(s => `${s.a}–${s.b}`).join('  ·  ')}
                  </div>
                </div>
              </div>
            </div>

            {/* Vs strip — winner vs loser visual */}
            <div style={{
              display: 'grid', gridTemplateColumns: '1fr auto 1fr',
              alignItems: 'center', gap: 0,
              padding: '20px 32px',
              borderTop: `1px solid ${t.line}`,
              background: t.bgAlt,
            }}>
              <PlayerLine t={t} player={W} color={wColor} side={winner} sets={winner === 'A' ? setsA : setsB} won align="right" />
              <div style={{
                fontFamily: t.fontDisplay,
                fontWeight: t.displayWeight,
                fontSize: 14,
                color: t.textFaint,
                letterSpacing: '0.18em',
                textTransform: 'uppercase',
                padding: '0 24px',
              }}>vs</div>
              <PlayerLine t={t} player={L} color={lColor} side={winner === 'A' ? 'B' : 'A'} sets={winner === 'A' ? setsB : setsA} won={false} align="left" />
            </div>
          </Card>

          {/* Bottom row: set breakdown + MMR change + actions */}
          <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 20 }}>
            {/* Set-by-set breakdown */}
            <Card t={t}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
                <div style={{
                  fontFamily: t.fontDisplay,
                  fontWeight: t.displayWeight,
                  fontSize: 16,
                  textTransform: t.labelTransform,
                  letterSpacing: t.labelLetter,
                }}>Разбор по сетам</div>
                <Label t={t}>BO3 · до 2 побед</Label>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {history.map(s => (
                  <div key={s.n} style={{
                    display: 'grid',
                    gridTemplateColumns: '60px 1fr auto 60px',
                    alignItems: 'center',
                    gap: 14,
                    padding: '12px 14px',
                    background: t.surface2,
                    borderRadius: t.radius,
                    border: `1px solid ${t.line}`,
                  }}>
                    <Label t={t}>сет {s.n}</Label>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <div style={{
                        width: 10, height: 10, borderRadius: t.key === 'volt' ? 0 : '50%',
                        background: s.winner === 'A' ? t.accent : '#3b82f6',
                      }} />
                      <span style={{ fontFamily: t.fontMono, fontSize: 12, color: t.textMuted, letterSpacing: '0.08em', textTransform: 'uppercase' }}>
                        выиграл {s.winner === 'A' ? A.name : B.name}
                      </span>
                    </div>
                    <div style={{
                      fontFamily: t.fontDisplay,
                      fontWeight: t.displayWeight,
                      fontSize: 26,
                      fontVariantNumeric: 'tabular-nums',
                      letterSpacing: t.key === 'arena' ? '0.01em' : '-0.02em',
                    }}>
                      <span style={{ color: s.winner === 'A' ? t.accent : t.text, opacity: s.winner === 'B' ? 0.5 : 1 }}>{s.a}</span>
                      <span style={{ color: t.textFaint, padding: '0 4px' }}>–</span>
                      <span style={{ color: s.winner === 'B' ? '#3b82f6' : t.text, opacity: s.winner === 'A' ? 0.5 : 1 }}>{s.b}</span>
                    </div>
                    <div style={{ fontFamily: t.fontMono, fontSize: 11, color: t.textFaint, textAlign: 'right', letterSpacing: '0.04em' }}>{s.dur}</div>
                  </div>
                ))}
              </div>
            </Card>

            {/* MMR change + actions */}
            <Card t={t}>
              <div style={{
                fontFamily: t.fontDisplay,
                fontWeight: t.displayWeight,
                fontSize: 16,
                textTransform: t.labelTransform,
                letterSpacing: t.labelLetter,
                marginBottom: 14,
              }}>Изменение MMR</div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                <MmrRow t={t} player={W} cur={W.mmr} after={W.mmrAfter} color={wColor} won />
                <MmrRow t={t} player={L} cur={L.mmr} after={L.mmrAfter} color={lColor} won={false} />
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 18 }}>
                <Btn t={t} primary full>Реванш</Btn>
                <div style={{ display: 'flex', gap: 8 }}>
                  <Btn t={t} ghost full size="sm">Поделиться</Btn>
                  <Btn t={t} ghost full size="sm">На главную</Btn>
                </div>
                <Btn t={t} ghost full size="sm">
                  <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4"><path d="M3 12a9 9 0 1 0 9-9M3 4v8h8"/></svg>
                  Оспорить результат
                </Btn>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

const PlayerLine = ({ t, player, color, side, sets, won, align }) => (
  <div style={{
    display: 'flex',
    alignItems: 'center',
    gap: 14,
    flexDirection: align === 'right' ? 'row-reverse' : 'row',
    opacity: won ? 1 : 0.55,
  }}>
    <Avatar t={t} initials={player.init} color={color} size={44} />
    <div style={{ textAlign: align }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, justifyContent: align === 'right' ? 'flex-end' : 'flex-start' }}>
        <Label t={t} style={{ color }}>P{side}</Label>
        <Label t={t} style={{ color: won ? t.win : t.loss }}>{won ? 'WIN' : 'LOSS'}</Label>
      </div>
      <div style={{
        fontFamily: t.fontDisplay,
        fontWeight: t.displayWeight,
        fontSize: 18,
        marginTop: 2,
        color: t.text,
        letterSpacing: t.key === 'arena' ? '0.01em' : '-0.01em',
      }}>{player.name}</div>
    </div>
    <div style={{
      fontFamily: t.fontDisplay,
      fontWeight: t.displayWeight,
      fontSize: 36,
      color: won ? color : t.textFaint,
      fontVariantNumeric: 'tabular-nums',
      lineHeight: 1,
      padding: align === 'right' ? '0 0 0 12px' : '0 12px 0 0',
    }}>{sets}</div>
  </div>
);

const MmrRow = ({ t, player, cur, after, color, won }) => {
  const delta = after - cur;
  return (
    <div style={{
      padding: '12px 14px',
      background: t.surface2,
      borderRadius: t.radius,
      border: `1px solid ${won ? `${t.win}55` : t.line}`,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
        <Avatar t={t} initials={player.init} color={color} size={26} />
        <div style={{ fontSize: 13, color: t.text, fontWeight: 500 }}>{player.name}</div>
        <div style={{
          marginLeft: 'auto',
          fontFamily: t.fontMono, fontSize: 12, fontWeight: 700,
          color: won ? t.win : t.loss,
          letterSpacing: '0.04em',
        }}>
          {delta > 0 ? `+${delta}` : delta}
        </div>
      </div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
        <span style={{
          fontFamily: t.fontMono, fontSize: 13, color: t.textFaint,
          textDecoration: 'line-through',
          fontVariantNumeric: 'tabular-nums',
        }}>{cur}</span>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={t.textMuted} strokeWidth="2"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
        <span style={{
          fontFamily: t.fontDisplay, fontWeight: t.displayWeight,
          fontSize: 22, color: t.text,
          letterSpacing: t.key === 'arena' ? '0.01em' : '-0.02em',
          fontVariantNumeric: 'tabular-nums',
        }}>{after}</span>
      </div>
    </div>
  );
};

window.VictoryScreen = VictoryScreen;
