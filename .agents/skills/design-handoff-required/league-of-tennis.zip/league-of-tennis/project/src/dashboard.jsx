// Dashboard — current MMR (large), recent matches, opponents to challenge, stats.

const Dashboard = ({ t }) => {
  const mmr = 1247;
  const delta = +18;
  const tier = mmrTier(mmr);
  const next = tier.next ? tier.next - mmr : 0;
  const trend = [1098, 1112, 1090, 1124, 1156, 1140, 1172, 1198, 1184, 1210, 1229, 1247];

  return (
    <div style={{
      width: '100%', minHeight: '100%',
      background: t.bg,
      color: t.text,
      fontFamily: t.fontBody,
      display: 'flex',
      position: 'relative',
      overflow: 'hidden',
    }}>
      <ThemeBg t={t} />
      <DashSidebar t={t} active="dash" />

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <DashTopbar t={t} />

        <div style={{ padding: '24px 32px 40px', display: 'flex', flexDirection: 'column', gap: 20 }}>
          {/* HERO — MMR big */}
          <Card t={t} accent={t.key === 'arena'} style={{
            padding: 0, overflow: 'hidden',
            background: t.key === 'baseline'
              ? `linear-gradient(135deg, rgba(77,212,255,.10), rgba(167,139,250,.06)), ${t.surface}`
              : t.surface,
          }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 0 }}>
              {/* MMR mega */}
              <div style={{ padding: '32px 36px', borderRight: `1px solid ${t.line}`, position: 'relative' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 18 }}>
                  <div style={{ width: 8, height: 8, borderRadius: '50%', background: t.win, boxShadow: `0 0 8px ${t.win}` }} />
                  <Label t={t}>текущий MMR · {tier.name}</Label>
                </div>
                <div style={{
                  display: 'flex', alignItems: 'baseline', gap: 12,
                  fontFamily: t.fontDisplay,
                  fontWeight: t.displayWeight,
                  fontVariantNumeric: 'tabular-nums',
                }}>
                  <div style={{
                    fontSize: 132, lineHeight: 0.85,
                    color: t.text,
                    letterSpacing: t.key === 'arena' ? '0.005em' : '-0.04em',
                  }}>{mmr}</div>
                  <div style={{
                    fontSize: 22, color: t.win,
                    fontFamily: t.fontMono,
                    fontWeight: 600,
                    paddingBottom: 12,
                  }}>+{delta}</div>
                </div>
                {/* Tier progress */}
                <div style={{ marginTop: 22 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                    <Label t={t}>{tier.name}</Label>
                    <span style={{ fontFamily: t.fontMono, fontSize: 11, color: t.textMuted, letterSpacing: '0.08em' }}>
                      {next > 0 ? `+${next} до ${tier.nextName}` : 'MAX'}
                    </span>
                  </div>
                  <div style={{ height: 6, background: t.surface2, borderRadius: t.key === 'volt' ? 0 : 3, position: 'relative', overflow: 'hidden' }}>
                    <div style={{
                      position: 'absolute', inset: '0 auto 0 0',
                      width: `${(1 - next / 250) * 100}%`,
                      background: t.accent,
                      boxShadow: t.key === 'baseline' ? `0 0 12px ${t.accent}` : 'none',
                    }} />
                    {t.key === 'arena' && Array.from({ length: 9 }).map((_, i) => (
                      <div key={i} style={{ position: 'absolute', top: 0, bottom: 0, left: `${(i + 1) * 10}%`, width: 1, background: t.bg }} />
                    ))}
                  </div>
                </div>
              </div>

              {/* Quick stats */}
              <div style={{ padding: '24px 24px', display: 'flex', flexDirection: 'column', gap: 14 }}>
                <StatRow t={t} label="Винрейт" value="68%" sub="34 / 50" />
                <StatRow t={t} label="Серия побед" value="5W" sub="лучшая · 9W" accent />
                <StatRow t={t} label="Любимый формат" value="bo3" sub="62% матчей" />
                <StatRow t={t} label="Средняя разница" value="+4.2" sub="очков за сет" />
              </div>
            </div>
          </Card>

          {/* ROW — challenge + recent + ladder */}
          <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1.4fr 1fr', gap: 20 }}>
            {/* Challenge a player */}
            <Card t={t} style={{ padding: 22 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
                <div style={{
                  fontFamily: t.fontDisplay,
                  fontWeight: t.displayWeight,
                  fontSize: 18,
                  textTransform: t.labelTransform,
                  letterSpacing: t.key === 'baseline' ? '-0.01em' : t.labelLetter,
                }}>Бросить вызов</div>
                <a style={{ fontSize: 12, color: t.accent, fontFamily: t.fontMono, letterSpacing: '0.08em', textTransform: 'uppercase' }}>+ новый</a>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {[
                  { name: 'k.volkov', mmr: 1289, init: 'KV', col: '#3b82f6', win: '4–2' },
                  { name: 'silentforehand', mmr: 1198, init: 'SF', col: '#a855f7', win: '2–3' },
                  { name: 'maria.tk', mmr: 1331, init: 'MT', col: '#ec4899', win: '1–2' },
                ].map((p, i) => (
                  <div key={i} style={{
                    display: 'flex', alignItems: 'center', gap: 12,
                    padding: 10, borderRadius: t.radius,
                    background: t.surface2,
                    border: t.key === 'volt' ? `1px solid ${t.line}` : 'none',
                  }}>
                    <Avatar t={t} initials={p.init} color={p.col} size={36} />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 14, fontWeight: 500, color: t.text }}>{p.name}</div>
                      <div style={{ fontSize: 11, color: t.textFaint, fontFamily: t.fontMono, letterSpacing: '0.04em' }}>
                        MMR {p.mmr} · H2H {p.win}
                      </div>
                    </div>
                    <Btn t={t} size="sm" primary>Челлендж</Btn>
                  </div>
                ))}
              </div>
            </Card>

            {/* Recent matches */}
            <Card t={t} style={{ padding: 22 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
                <div style={{
                  fontFamily: t.fontDisplay,
                  fontWeight: t.displayWeight,
                  fontSize: 18,
                  textTransform: t.labelTransform,
                  letterSpacing: t.key === 'baseline' ? '-0.01em' : t.labelLetter,
                }}>Последние матчи</div>
                <a style={{ fontSize: 12, color: t.accent, fontFamily: t.fontMono, letterSpacing: '0.08em', textTransform: 'uppercase' }}>все →</a>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column' }}>
                {[
                  { vs: 'k.volkov', sets: '3–2', fmt: 'bo5', d: '+22', win: true, when: '2 ч' },
                  { vs: 'maria.tk', sets: '1–2', fmt: 'bo3', d: '−14', win: false, when: 'вчера' },
                  { vs: 'd.smirnov', sets: '2–0', fmt: 'bo3', d: '+19', win: true, when: 'вчера' },
                  { vs: 'silentforehand', sets: '2–1', fmt: 'bo3', d: '+27', win: true, when: '2 дня' },
                  { vs: 'tomas.pl', sets: '0–2', fmt: 'bo3', d: '−21', win: false, when: '3 дня' },
                ].map((m, i) => (
                  <div key={i} style={{
                    display: 'grid',
                    gridTemplateColumns: '14px 1fr auto auto auto',
                    gap: 12,
                    alignItems: 'center',
                    padding: '11px 0',
                    borderBottom: i < 4 ? `1px solid ${t.lineSoft}` : 'none',
                  }}>
                    <div style={{
                      width: 4, height: 22,
                      background: m.win ? t.win : t.loss,
                      borderRadius: 1,
                    }} />
                    <div style={{ minWidth: 0 }}>
                      <div style={{ fontSize: 13, color: t.text }}>vs <span style={{ fontWeight: 500 }}>{m.vs}</span></div>
                      <div style={{ fontSize: 11, color: t.textFaint, fontFamily: t.fontMono, letterSpacing: '0.04em' }}>{m.fmt} · {m.when}</div>
                    </div>
                    <div style={{
                      fontFamily: t.fontMono,
                      fontWeight: 600,
                      fontSize: 13,
                      color: t.text,
                      fontVariantNumeric: 'tabular-nums',
                    }}>{m.sets}</div>
                    <div style={{
                      fontFamily: t.fontMono,
                      fontSize: 12,
                      fontWeight: 600,
                      color: m.win ? t.win : t.loss,
                      fontVariantNumeric: 'tabular-nums',
                      minWidth: 36, textAlign: 'right',
                    }}>{m.d}</div>
                    <div style={{
                      width: 22, height: 22,
                      borderRadius: t.radius,
                      background: m.win ? t.accentSoft : 'transparent',
                      border: m.win ? 'none' : `1px solid ${t.line}`,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontSize: 10,
                      fontWeight: 700,
                      color: m.win ? t.accent : t.textFaint,
                      fontFamily: t.fontMono,
                    }}>{m.win ? 'W' : 'L'}</div>
                  </div>
                ))}
              </div>
            </Card>

            {/* Leaderboard mini */}
            <Card t={t} style={{ padding: 22 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
                <div style={{
                  fontFamily: t.fontDisplay,
                  fontWeight: t.displayWeight,
                  fontSize: 18,
                  textTransform: t.labelTransform,
                  letterSpacing: t.key === 'baseline' ? '-0.01em' : t.labelLetter,
                }}>Топ лиги</div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {[
                  ['1', 'maria.tk', 1331, '#ec4899'],
                  ['2', 'k.volkov', 1289, '#3b82f6'],
                  ['3', 'a.morozov', 1247, t.accent, true],
                  ['4', 'silentforehand', 1198, '#a855f7'],
                  ['5', 'd.smirnov', 1184, '#f97316'],
                ].map(([rk, nm, mr, col, me], i) => (
                  <div key={i} style={{
                    display: 'grid', gridTemplateColumns: '20px 24px 1fr auto', gap: 10,
                    alignItems: 'center',
                    padding: '8px 10px', margin: '0 -10px',
                    background: me ? t.accentSoft : 'transparent',
                    borderRadius: t.radius,
                    border: me ? `1px solid ${t.accent}` : 'none',
                  }}>
                    <div style={{
                      fontFamily: t.fontMono,
                      fontSize: 11,
                      fontWeight: 700,
                      color: i < 3 ? t.accent : t.textFaint,
                      textAlign: 'center',
                    }}>{rk}</div>
                    <Avatar t={t} initials={nm.slice(0, 2).toUpperCase()} color={col} size={22} />
                    <div style={{ fontSize: 13, color: t.text, fontWeight: me ? 600 : 400 }}>
                      {nm}{me && <span style={{ color: t.textFaint, fontSize: 11, marginLeft: 6 }}>(ты)</span>}
                    </div>
                    <div style={{
                      fontFamily: t.fontMono,
                      fontWeight: 600,
                      fontSize: 12,
                      color: t.text,
                      fontVariantNumeric: 'tabular-nums',
                    }}>{mr}</div>
                  </div>
                ))}
              </div>
            </Card>
          </div>

        </div>
      </div>
    </div>
  );
};

const StatRow = ({ t, label, value, sub, accent }) => (
  <div>
    <Label t={t} style={{ marginBottom: 4 }}>{label}</Label>
    <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
      <div style={{
        fontFamily: t.fontDisplay,
        fontWeight: t.displayWeight,
        fontSize: 22,
        color: accent ? t.accent : t.text,
        fontVariantNumeric: 'tabular-nums',
        letterSpacing: t.key === 'arena' ? '0.02em' : '-0.01em',
      }}>{value}</div>
      <div style={{ fontSize: 11, color: t.textFaint, fontFamily: t.fontMono, letterSpacing: '0.04em' }}>{sub}</div>
    </div>
  </div>
);

const BigSpark = ({ t, data }) => {
  const w = 360, h = 140;
  const min = Math.min(...data) - 10, max = Math.max(...data) + 10;
  const range = max - min;
  const pts = data.map((v, i) => [(i / (data.length - 1)) * w, h - ((v - min) / range) * h]);
  const d = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ');
  const dArea = d + ` L${w},${h} L0,${h} Z`;
  const last = pts[pts.length - 1];
  return (
    <svg viewBox={`0 0 ${w} ${h + 20}`} style={{ width: '100%', height: 160, display: 'block' }}>
      <defs>
        <linearGradient id={`grad-${t.key}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={t.accent} stopOpacity="0.35" />
          <stop offset="100%" stopColor={t.accent} stopOpacity="0" />
        </linearGradient>
      </defs>
      {/* baseline */}
      <line x1="0" y1={h - 1} x2={w} y2={h - 1} stroke={t.line} strokeWidth="1" />
      {[0.25, 0.5, 0.75].map(p => (
        <line key={p} x1="0" y1={h * p} x2={w} y2={h * p} stroke={t.lineSoft} strokeWidth="1" strokeDasharray={t.key === 'volt' ? '2 4' : '1 4'} />
      ))}
      <path d={dArea} fill={`url(#grad-${t.key})`} />
      <path d={d} stroke={t.accent} strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
      {pts.map((p, i) => (
        <circle key={i} cx={p[0]} cy={p[1]} r={i === pts.length - 1 ? 4 : 2} fill={t.bg} stroke={t.accent} strokeWidth="1.5" />
      ))}
      {/* current label */}
      <g>
        <rect x={last[0] - 26} y={last[1] - 28} width="52" height="20" fill={t.accent} rx={t.radius} />
        <text x={last[0]} y={last[1] - 14} textAnchor="middle" fontSize="11" fontWeight="700" fontFamily={t.fontMono} fill={t.bg}>{data[data.length-1]}</text>
      </g>
    </svg>
  );
};

const DashSidebar = ({ t, active }) => {
  const items = [
    ['dash', 'Дашборд', 'M3 12h7V3H3v9zm0 9h7v-7H3v7zm9 0h7v-9h-7v9zm0-18v7h7V3h-7z'],
    ['play', 'Играть', 'M8 5v14l11-7z'],
    ['ladder', 'Лидерборд', 'M4 22h16v-2H4v2zM6 18h4v-7H6v7zm5 0h4v-12h-4v12zm5 0h4V8h-4v10z'],
    ['matches', 'Матчи', 'M3 5h18v2H3zm0 6h18v2H3zm0 6h18v2H3z'],
    ['profile', 'Профиль', 'M12 12c2 0 4-2 4-4s-2-4-4-4-4 2-4 4 2 4 4 4zm0 2c-3 0-8 1-8 4v2h16v-2c0-3-5-4-8-4z'],
  ];
  return (
    <div style={{
      width: 220, flex: '0 0 220px',
      background: t.bgAlt,
      borderRight: `1px solid ${t.line}`,
      padding: '20px 14px',
      display: 'flex', flexDirection: 'column', gap: 4,
    }}>
      <div style={{ padding: '6px 10px 18px' }}>
        <Logo t={t} size={24} />
      </div>
      <Label t={t} style={{ padding: '8px 10px', marginTop: 4 }}>навигация</Label>
      {items.map(([k, lbl, d]) => {
        const on = k === active;
        return (
          <div key={k} style={{
            display: 'flex', alignItems: 'center', gap: 12,
            padding: '10px 12px',
            borderRadius: t.radius,
            background: on ? t.accentSoft : 'transparent',
            color: on ? t.accent : t.textMuted,
            fontSize: 14,
            fontWeight: on ? 600 : 400,
            cursor: 'pointer',
            position: 'relative',
          }}>
            {on && t.key === 'arena' && <div style={{ position: 'absolute', left: 0, top: 8, bottom: 8, width: 3, background: t.accent }} />}
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d={d} /></svg>
            {lbl}
          </div>
        );
      })}
      <div style={{ flex: 1 }} />
    </div>
  );
};

const DashTopbar = ({ t }) => (
  <div style={{
    height: 64,
    padding: '0 32px',
    borderBottom: `1px solid ${t.line}`,
    display: 'flex', alignItems: 'center', gap: 16,
    background: t.bg,
  }}>
    <div style={{
      flex: 1, maxWidth: 360,
      height: 38,
      padding: '0 14px',
      display: 'flex', alignItems: 'center', gap: 10,
      background: t.surface,
      border: `1px solid ${t.line}`,
      borderRadius: t.radius,
      color: t.textFaint,
      fontSize: 13,
    }}>
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>
      Найти игрока, матч, турнир
      <span style={{ marginLeft: 'auto', fontFamily: t.fontMono, fontSize: 11, padding: '2px 6px', background: t.surface2, borderRadius: 3 }}>⌘K</span>
    </div>
    <div style={{ flex: 1 }} />
    <Btn t={t} primary icon={<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M12 5v14M5 12h14"/></svg>}>Создать матч</Btn>
    <div style={{
      width: 38, height: 38,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: t.surface,
      border: `1px solid ${t.line}`,
      borderRadius: t.radius,
      color: t.textMuted,
      position: 'relative',
    }}>
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10 21a2 2 0 0 0 4 0"/></svg>
      <div style={{ position: 'absolute', top: 6, right: 6, width: 8, height: 8, borderRadius: '50%', background: t.accent }} />
    </div>
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, paddingLeft: 12, borderLeft: `1px solid ${t.line}` }}>
      <Avatar t={t} initials="AM" color={t.accent} size={36} />
      <div>
        <div style={{ fontSize: 13, fontWeight: 600, color: t.text }}>a.morozov</div>
        <div style={{ fontFamily: t.fontMono, fontSize: 10, color: t.textFaint, letterSpacing: '0.06em' }}>MMR 1247 · #04</div>
      </div>
    </div>
  </div>
);

function mmrTier(mmr) {
  const tiers = [
    { name: 'BRONZE', min: 0, max: 999 },
    { name: 'SILVER', min: 1000, max: 1199 },
    { name: 'GOLD', min: 1200, max: 1399 },
    { name: 'PLATINUM', min: 1400, max: 1599 },
    { name: 'DIAMOND', min: 1600, max: 1999 },
    { name: 'CHAMPION', min: 2000, max: 9999 },
  ];
  const i = tiers.findIndex(t => mmr >= t.min && mmr <= t.max);
  const cur = tiers[i];
  const nx = tiers[i + 1];
  return {
    name: cur.name,
    next: nx ? nx.min : null,
    nextName: nx ? nx.name : null,
  };
}

Object.assign(window, { Dashboard, DashSidebar, DashTopbar, mmrTier });
