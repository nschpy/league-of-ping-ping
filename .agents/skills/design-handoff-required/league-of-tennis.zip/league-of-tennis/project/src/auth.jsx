// Auth screen — SignIn/SignUp with toggle. Themed.

const AuthScreen = ({ t, mode = 'signin' }) => {
  const isUp = mode === 'signup';
  return (
    <div style={{
      width: '100%', height: '100%',
      background: t.bg,
      color: t.text,
      fontFamily: t.fontBody,
      display: 'flex',
      position: 'relative',
      overflow: 'hidden',
    }}>
      <ThemeBg t={t} />

      {/* LEFT — branded panel */}
      <div style={{
        flex: '0 0 52%',
        position: 'relative',
        padding: '40px 56px',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        background: t.key === 'arena'
          ? `linear-gradient(180deg, ${t.bgAlt}, ${t.bg})`
          : t.key === 'volt'
            ? t.bg
            : `linear-gradient(155deg, rgba(77,212,255,.08), transparent 60%), ${t.bgAlt}`,
        borderRight: `1px solid ${t.line}`,
      }}>
        <Logo t={t} size={28} />

        {/* Hero copy + decorative court */}
        <div style={{ position: 'relative' }}>
          {/* Court SVG behind */}
          <svg viewBox="0 0 600 360" style={{
            position: 'absolute', inset: 0, width: '100%', height: '100%',
            opacity: t.key === 'volt' ? 0.4 : 0.18,
            pointerEvents: 'none',
          }}>
            <rect x="40" y="60" width="520" height="240" stroke={t.accent} strokeWidth="2" fill="none" />
            <line x1="300" y1="60" x2="300" y2="300" stroke={t.accent} strokeWidth="1.5" strokeDasharray={t.key === 'volt' ? '4 4' : 'none'} />
            <line x1="40" y1="180" x2="560" y2="180" stroke={t.accent} strokeWidth="1" opacity="0.5" />
            <circle cx="240" cy="140" r="6" fill={t.accent} />
            <path d="M250 145 L380 240" stroke={t.accent} strokeWidth="1.2" strokeDasharray="2 4" />
            <circle cx="380" cy="240" r="4" fill={t.accent} opacity="0.6" />
          </svg>
          <div style={{
            fontFamily: t.fontDisplay,
            fontWeight: t.displayWeight,
            fontSize: 72,
            lineHeight: 0.92,
            letterSpacing: t.key === 'arena' ? '0.005em' : '-0.03em',
            textTransform: t.key === 'arena' || t.key === 'volt' ? 'uppercase' : 'none',
            color: t.text,
            position: 'relative',
            marginBottom: 20,
          }}>
            {t.key === 'arena' ? <>Rule the<br/><span style={{ color: t.accent }}>Table.</span></> :
             t.key === 'volt' ? <>Climb<br/>the <span style={{ color: t.accent }}>ladder_</span></> :
             <>Every rally<br/>has a <span style={{ color: t.accent }}>rating.</span></>}
          </div>
          <div style={{
            fontFamily: t.fontBody,
            fontSize: 15,
            color: t.textMuted,
            maxWidth: 440,
            lineHeight: 1.55,
            position: 'relative',
          }}>
            Соревновательная платформа по настольному теннису. Регистрируйся, играй матчи, поднимай MMR.
          </div>
        </div>

        {/* Stat strip */}
        <div style={{ display: 'flex', gap: 0, position: 'relative' }}>
          {[
            ['12,408', 'Игроков'],
            ['43,711', 'Матчей сыграно'],
            ['+25', 'MMR за победу'],
          ].map(([n, l], i) => (
            <div key={i} style={{
              flex: 1,
              padding: i === 0 ? '0 16px 0 0' : '0 16px',
              borderLeft: i ? `1px solid ${t.line}` : 'none',
            }}>
              <div style={{
                fontFamily: t.fontDisplay,
                fontWeight: t.displayWeight,
                fontSize: 28,
                color: t.text,
                letterSpacing: t.key === 'arena' ? '0.02em' : '-0.02em',
                fontVariantNumeric: 'tabular-nums',
              }}>{n}</div>
              <Label t={t} style={{ marginTop: 4 }}>{l}</Label>
            </div>
          ))}
        </div>
      </div>

      {/* RIGHT — form */}
      <div style={{
        flex: 1,
        padding: '64px 56px',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        position: 'relative',
      }}>
        {/* Toggle */}
        <div style={{
          display: 'inline-flex',
          padding: 4,
          background: t.surface,
          borderRadius: t.radius,
          border: `1px solid ${t.line}`,
          marginBottom: 36,
          alignSelf: 'flex-start',
        }}>
          {[['signin', 'Войти'], ['signup', 'Регистрация']].map(([k, lbl]) => {
            const active = (k === 'signup') === isUp;
            return (
              <div key={k} style={{
                padding: '8px 18px',
                borderRadius: t.radius,
                background: active ? t.accent : 'transparent',
                color: active ? t.bg : t.textMuted,
                fontFamily: t.fontDisplay,
                fontWeight: t.displayWeight,
                fontSize: 13,
                letterSpacing: t.labelLetter,
                textTransform: t.labelTransform,
                cursor: 'pointer',
                transition: 'all .15s',
              }}>{lbl}</div>
            );
          })}
        </div>

        <div style={{
          fontFamily: t.fontDisplay,
          fontWeight: t.displayWeight,
          fontSize: 38,
          lineHeight: 1,
          color: t.text,
          marginBottom: 8,
          letterSpacing: t.key === 'baseline' ? '-0.02em' : '0',
          textTransform: t.key === 'arena' ? 'uppercase' : 'none',
        }}>
          {isUp ? 'Создать аккаунт' : 'С возвращением'}
        </div>
        <div style={{ color: t.textMuted, fontSize: 14, marginBottom: 32 }}>
          {isUp ? 'Стартовый MMR — 1000. Поехали.' : 'Возьми ракетку и продолжим.'}
        </div>

        {/* Fields */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
          {isUp && (
            <FormField t={t} label="Никнейм" placeholder="thunder.spin" hint="будет видно соперникам" />
          )}
          <FormField t={t} label="E-mail" placeholder="player@league.tennis" value={isUp ? '' : 'a.morozov@league.tennis'} />
          <FormField t={t} label="Пароль" placeholder="••••••••••" value="••••••••••" type="password" />
          {!isUp && (
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: -4 }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: t.textMuted, cursor: 'pointer' }}>
                <span style={{
                  width: 16, height: 16, borderRadius: t.key === 'baseline' ? 4 : 2,
                  border: `1.5px solid ${t.line}`,
                  background: t.accent,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <svg width="10" height="10" viewBox="0 0 10 10" fill="none"><path d="M2 5L4 7L8 3" stroke={t.bg} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>
                </span>
                Запомнить меня
              </label>
              <a style={{ fontSize: 13, color: t.accent, textDecoration: 'none', fontWeight: 500 }}>Забыли пароль?</a>
            </div>
          )}
        </div>

        <div style={{ marginTop: 28, display: 'flex', flexDirection: 'column', gap: 12 }}>
          <Btn t={t} primary full size="lg">{isUp ? 'Создать аккаунт →' : 'Войти →'}</Btn>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, color: t.textFaint, fontSize: 12, margin: '4px 0' }}>
            <div style={{ flex: 1, height: 1, background: t.line }} />
            <span style={{
              fontFamily: t.fontMono, letterSpacing: '0.16em', textTransform: 'uppercase',
            }}>или</span>
            <div style={{ flex: 1, height: 1, background: t.line }} />
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <Btn t={t} ghost full>Google</Btn>
            <Btn t={t} ghost full>Telegram</Btn>
          </div>
        </div>

        <div style={{ marginTop: 'auto', paddingTop: 32, fontSize: 12, color: t.textFaint, fontFamily: t.fontMono }}>
          {t.key === 'volt' ? '> ' : ''}v1.4.0 · {t.name}
        </div>
      </div>
    </div>
  );
};

const FormField = ({ t, label, placeholder, value, hint, type }) => (
  <div>
    <Label t={t} style={{ marginBottom: 8 }}>{label}</Label>
    <div style={{
      position: 'relative',
      borderRadius: t.radius,
      background: t.surface,
      border: `1px solid ${value ? t.line : t.lineSoft}`,
    }}>
      <div style={{
        padding: '14px 16px',
        fontSize: 15,
        color: value ? t.text : t.textFaint,
        fontFamily: t.fontBody,
        letterSpacing: type === 'password' && value ? '0.2em' : 'normal',
      }}>
        {value || placeholder}
      </div>
    </div>
    {hint && <div style={{ marginTop: 6, fontSize: 12, color: t.textFaint }}>{hint}</div>}
  </div>
);

window.AuthScreen = AuthScreen;
